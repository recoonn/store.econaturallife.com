<?php
// Text
$_['text_subject']      = '%s - Заказ %s';
$_['text_received']     = 'Вы получили заказ.';
$_['text_order_id']     = '№ заказа:';
$_['text_date_added']   = 'Дата заказа:';
$_['text_order_status'] = 'Состояние заказа:';
$_['text_product']      = 'Товары';
$_['text_total']        = 'Итого';
$_['text_comment']      = 'Комментарий к Вашему заказу:';
