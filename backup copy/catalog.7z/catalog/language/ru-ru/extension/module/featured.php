<?php
// Heading
$_['heading_title'] = 'Заказывают сейчас...';

// Text
$_['text_tax']      = 'Без НДС:';

