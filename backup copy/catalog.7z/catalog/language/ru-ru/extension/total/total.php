<?php
// Text
$_['text_total'] = 'Итого';

