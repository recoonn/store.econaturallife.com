<?php
// Text
$_['text_title']          = 'PayPal Экспресс-платежи';
$_['text_canceled']       = 'Оплата успешно отменена!';

// Button
$_['button_cancel']       = 'Отменить периодические платежи';

// Error
$_['error_not_cancelled'] = 'Ошибка: %s';
$_['error_not_found']     = 'Нельзя отменить профиль';

