<?php
// Text
$_['text_search'] = 'Поиск по сайту ...';
